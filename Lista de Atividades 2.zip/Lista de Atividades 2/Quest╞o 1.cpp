#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	setlocale(LC_ALL,"portuguese");
	int a,b,c,d,diferenca;
	
	printf("Digite 4 valores inteiros:\n");
	scanf("%d" "%d" "%d" "%d",&a,&b,&c,&d);
	
	diferenca=(a*b-c*d);
	
	printf("\nDifere�a = %d * %d - %d * %d\n",a,b,c,d);
	printf("Diferen�a = %d\n",diferenca);
	return 0;
}
