#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	setlocale(LC_ALL,"portuguese");
	int i,val[10],media;
	
	printf("Digite 10 n�meros inteiros:\n");
	for(i=0,media=0;i<10;media+=val[i++]){
		scanf("%d",&val[i]);
	}
	printf("A m�dia dos n�meros inteiros �: %d",media/10);
}
