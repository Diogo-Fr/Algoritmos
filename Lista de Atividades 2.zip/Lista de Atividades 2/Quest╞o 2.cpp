#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
#include<math.h>

int main(){
	setlocale(LC_ALL,"portuguese");
	float x1,y1,x2,y2,distancia;
	
	printf("Digite as coordenadas do x1 e y1:\n");
	scanf("%f" "%f",&x1,&y1);
	
	printf("\nDigite as coordenadas do x2 e y2:\n");
	scanf("%f" "%f",&x2,&y2);
	
	distancia = sqrt(pow(x2-x1,2) + pow(y2-y1,2));	
	
	printf("\nA dist�ncia entre os pontos �: %.4f\n",distancia);
	return 0;
}
