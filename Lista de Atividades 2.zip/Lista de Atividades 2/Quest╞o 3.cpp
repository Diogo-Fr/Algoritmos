#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
#include<math.h>
#define PI 3.14159

int main(){
	setlocale(LC_ALL,"portuguese");
	float volume,area,r,pi;
	
	printf("Digite o valor do raio (R) da esfera:\n");
	scanf("%f",&r);
	
	volume = 4.0/3*PI*pow(r,3);
	area = 4 *PI*pow(r,2);
	
	printf("\n O volume da esfera �: %f",volume);
	printf("\nA �rea da esfera �: %f\n",area);
	return 0;
}
