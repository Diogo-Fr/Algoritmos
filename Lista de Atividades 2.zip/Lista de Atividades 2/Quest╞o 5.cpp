#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	setlocale(LC_ALL,"portuguese");
	int i,n;
	
	printf("Digite um n�mero inteiro positivo:\n");
	scanf("%d",&n);
	
	printf("Os divisores de %d s�o:\n",n);
	for(i=n;i<=n;i--){
		if(n % i==0){
			printf("%d",i);
			printf("\n");
		}
	}
	return 0;
}
