#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
#define N 1000
int main(){
	setlocale(LC_ALL,"portuguese");
	int i,soma;
	
	printf("Todos os m�ltiplos de 3 e 5 at� 1000:\n");
	printf("\n");
	for(i=1;i<N;i++){
		if(i % 3==0 || i % 5==0){
			soma+=i;
			printf("%d",i);
			printf("-");
		}
	}
	printf("\n");
	printf("\nA soma dos m�ltiplos de 3 e 5 �: %d\n",soma);
}
