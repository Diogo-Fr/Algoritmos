#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int fin(int n){
	if(n==1){
		return 0;
	}
	else if(n==2){
		return 1;
	}
	else
	return fin(n-1) + fin(n-2);
}

int main(){
	setlocale(LC_ALL,"portuguese");
	int n;
	
	printf("Digite um n�mero inteiro:\n");
	scanf("%d",&n);
	
	printf("O resultado �: %d",fin(n));
}
