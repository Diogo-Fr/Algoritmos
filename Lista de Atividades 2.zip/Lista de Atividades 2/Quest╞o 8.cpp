#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	setlocale(LC_ALL,"portuguese");
	int max,min,n,i;
	
	printf("Digite v�rios n�meros inteiros (negativo para parar):\n");
	scanf("%d",&n);
	max=n;
	min=n;
	
	while(n>0){
		if(n>max){
			max=n;
		}
		if(n<min){
			min=n;
		}
		printf("Digite v�rios n�meros inteiros (negativo para parar):\n");
		scanf("%d",&n);
	}
	printf("\nO maior n�mero digitado foi: %d\n",max);
	printf("O menor n�mero digitado foi: %d\n",min);
}
