#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	setlocale(LC_ALL,"portuguese");
	int fruta,quant;
	float a,m,p;
	char stop;

	do{
		printf("Lista de frutas e seus pre�os:\n");
		printf("\n1 => Abacaxi - 5,00 a unidade\n2 => Ma�� - 1,00 a unidade\n3 => P�ra - 4,00 a unidade\n\n");
		system ("pause");
		system ("cls");
		printf("Escolha a fruta de acordo com o n�mero (0 para voltar ao menu de frutas):\n");
		scanf("%d",&fruta);
	}
	while(fruta==0);
		if(fruta>=1 && fruta<=3){
			printf("\nQuantas unidades voc� quer:\n");
			scanf("%d",&quant);
	
			switch(fruta){
				case 1:
					a=5*quant;
					printf("\nVoc� escolheu %d unidades de abacaxi, o pre�o total �: %.2f reais.\n",quant,a);
					break;
				case 2:
					m=1*quant;
					printf("\nVoc� escolheu %d unidades de ma��, o pre�o total �: %.2f reais.\n",quant,m);
					break;
				case 3:
					p=4*quant;
					printf("\nVoc� escolheu %d unidades de p�ra, o pre�o total �: %.2f reais.\n",quant,p);
					break;
			}
		}
		else
			printf("\nEssa fruta n�o est� no menu!\n");
}
